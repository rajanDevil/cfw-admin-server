module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'cfwdb'
    },
	'database': 'cfwdb',
};